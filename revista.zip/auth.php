
<?php 

session_start();
include "conexion.php"; 
$usuario=strtolower($_POST['usuario']);
$clave=$_POST['clave'];



			$sql="select * from cliente where login='$usuario'";
			$result=mysql_query($sql, $conexion) or die (mysql_error());

			//No existe el usuario
			if (!mysql_num_rows($result)>0)
				{

				echo "Usuario y/o clave incorrecta";
				
				exit();				
				}
					
					
					 while ($row=@mysql_fetch_array($result)) 
					{ 
						if ($usuario==$row['login'] && $clave==$row['clave'])
						{
						$_SESSION["usuario"] = $row['login'];
						$_SESSION["clave"] = $row['clave'];
						$_SESSION["nombre"] = $row['nombre'];
						$_SESSION["apellido"] = $row['apellido'];
						$_SESSION["mail"] = $row['correo'];
						$_SESSION["dni"] = $row['dni'];
						$_SESSION["telefono"] = $row['telefono'];
						$_SESSION["direccion"] = $row['direccion'];
						$_SESSION["genero"] = $row['genero'];
						$_SESSION["fecha_nacimiento"] = $row['fecha_nacimiento'];
						
						header ("Location: index.php");		//Logueamos y enviamos al index	
					
						}
					
					
					} 
										
				
			
			
					
					
?> 